# Nursery-Store-Django
A platform to sell plants by ordering online
